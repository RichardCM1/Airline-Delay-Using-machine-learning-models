% PSO 15 Iterations
% rng default
global initial_flag
opts = optimoptions('particleswarm','PlotFcn',{@pswplotbestf});
% Define the dimensions
D = [2, 10];

% Initialize arrays to store results for D=2 and D=10
sp_val_f1 = cell(1, length(D));
sp_exit_f1 = cell(1, length(D));
sp_op_f1 = cell(1, length(D));

sp_val_f2 = cell(1, length(D));
sp_exit_f2 = cell(1, length(D));
sp_op_f2 = cell(1, length(D));

% Particle Swarm Optimization 
for dim = 1:length(D)
    dimension = D(dim);
    initial_flag = 0
    
    % Run PSO 
    for i = 1:15
        [x, val, exit_flag, op] = particleswarm(@(x)benchmark_func(x, 1), dimension, [-100, -100], [100, 100], opts);
        sp_val_f1{dim}(i) = val;
        sp_exit_f1{dim}(i) = exit_flag;
        sp_op_f1{dim}(i) = op;
        
        % Save visualizations to file
        filename = sprintf('pso_sph_D%d_I%d_f1.fig', dimension, i);
        savefig(filename);
    end
    
   initial_flag = 0
    for i = 1:15
        [x, val, exit_flag, op] = particleswarm(@(x)benchmark_func(x, 6), dimension, [-100, -100], [100, 100], opts);
        sp_val_f2{dim}(i) = val;
        sp_exit_f2{dim}(i) = exit_flag;
        sp_op_f2{dim}(i) = op;
        
        % Save visualizations to file
        filename = sprintf('pso_schw_D%d_I%d_f2.fig', dimension, i);
        savefig(filename);
    end
end

% PSO 15 iteration measures for Function 1, D=2
max_D2_f1 = max(sp_val_f1{1});
min_D2_f1 = min(sp_val_f1{1});
mean_D2_f1 = mean(sp_val_f1{1});
std_D2_f1 = std(sp_val_f1{1});

% PSO 15 iteration measures for Function 1, D=10
max_D10_f1 = max(sp_val_f1{2});
min_D10_f1 = min(sp_val_f1{2});
mean_D10_f1 = mean(sp_val_f1{2});
std_D10_f1 = std(sp_val_f1{2});


% Display results for Function 1, D=2 and D=10
disp('PSO Results for Function 1:')
disp(' ');
disp('D=2:');
disp(['Max Value: ', num2str(max_D2_f1)]);
disp(['Min Value: ', num2str(min_D2_f1)]);
disp(['Mean Value: ', num2str(mean_D2_f1)]);
disp(['Standard Deviation: ', num2str(std_D2_f1)]);
disp(' ');
disp('D=10:');
disp(['Max Value: ', num2str(max_D10_f1)]);
disp(['Min Value: ', num2str(min_D10_f1)]);
disp(['Mean Value: ', num2str(mean_D10_f1)]);
disp(['Standard Deviation: ', num2str(std_D10_f1)]);
disp(' ');

% PSO 15 iteration measures for Function 2, D=2
max_D2_f2 = max(sp_val_f2{1});
min_D2_f2 = min(sp_val_f2{1});
mean_D2_f2 = mean(sp_val_f2{1});
std_D2_f2 = std(sp_val_f2{1});

% PSO 15 iteration measures for Function 2, D=10
max_D10_f2 = max(sp_val_f2{2});
min_D10_f2 = min(sp_val_f2{2});
mean_D10_f2 = mean(sp_val_f2{2});
std_D10_f2 = std(sp_val_f2{2});

% Display results for Function 2, D=2 and D=10
disp('PSO Results for Function 2:')
disp(' ');
disp('D=2:');
disp(['Max Value: ', num2str(max_D2_f2)]);
disp(['Min Value: ', num2str(min_D2_f2)]);
disp(['Mean Value: ', num2str(mean_D2_f2)]);
disp(['Standard Deviation: ', num2str(std_D2_f2)]);
disp(' ');
disp('D=10:');
disp(['Max Value: ', num2str(max_D10_f2)]);
disp(['Min Value: ', num2str(min_D10_f2)]);
disp(['Mean Value: ', num2str(mean_D10_f2)]);
disp(['Standard Deviation: ', num2str(std_D10_f2)]);
