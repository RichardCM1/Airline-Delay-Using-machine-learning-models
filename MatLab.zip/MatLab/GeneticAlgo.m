clc, clear, close all
rng default
global f
opts = optimoptions('ga', 'PlotFcn', {@gaplotbestf, @gaplotdistance});

% Define the dimensions
dims = [2, 10];
val_res_f1 = cell(1, length(dims));
exit_res_f1 = cell(1, length(dims));
op_res_f1 = cell(1, length(dims));

val_res_f2 = cell(1, length(dims));
exit_res_f2 = cell(1, length(dims));
op_res_f2 = cell(1, length(dims));

% Genetic Algorithm Optimization 15 iterations 
for d = 1:length(dims)
    D = dims(d);
    
    % Sphere Function
    for i = 1:15
        global initial_flag
        initial_flag = 0;
        [x, val, exit_flag, op] = ga(@(x)benchmark_func(x, 1), D, opts);
        val_res_f1{d}(i) = val;
        exit_res_f1{d}(i) = exit_flag;
        op_res_f1{d}(i) = op;
        
        % Save visualizations to file
        na = sprintf('Sph_D%d_I%d_f1.fig', D, i);
        savefig(na);
    end
    
    % Rosenbrock function 6
    for i = 1:15
        global initial_flag
        initial_flag = 0;
        [x, val, exit_flag, op] = ga(@(x)benchmark_func(x, 6), D, opts);
        val_res_f2{d}(i) = val;
        exit_res_f2{d}(i) = exit_flag;
        op_res_f2{d}(i) = op;
        
        % Save visualizations to file
        na = sprintf('rose_D%d_I%d_f2.fig', D, i);
        savefig(na);
    end
end

% GA 15 iteration measures for Function 1, D=2
max_D2_f1 = max(val_res_f1{1});
min_D2_f1 = min(val_res_f1{1});
mean_D2_f1 = mean(val_res_f1{1});
std_D2_f1 = std(val_res_f1{1});

% GA 15 iteration measures for Function 1, D=10
max_D10_f1 = max(val_res_f1{2});
min_D10_f1 = min(val_res_f1{2});
mean_D10_f1 = mean(val_res_f1{2});
std_D10_f1 = std(val_res_f1{2});

% Display results for Function 1, D=2 and D=10
disp('GA Results for 1:')
disp(' ');
disp('D=2:');
disp(['Max Value: ', num2str(max_D2_f1)]);
disp(['Min Value: ', num2str(min_D2_f1)]);
disp(['Mean Value: ', num2str(mean_D2_f1)]);
disp(['Standard Deviation: ', num2str(std_D2_f1)]);
disp(' ');
disp('D=10:');
disp(['Max Value: ', num2str(max_D10_f1)]);
disp(['Min Value: ', num2str(min_D10_f1)]);
disp(['Mean Value: ', num2str(mean_D10_f1)]);
disp(['Standard Deviation: ', num2str(std_D10_f1)]);
disp(' ');

% Genetic Algorithm 15 iteration measures for Function 2, D=2
max_D2_f2 = max(val_res_f2{1});
min_D2_f2 = min(val_res_f2{1});
mean_D2_f2 = mean(val_res_f2{1});
std_D2_f2 = std(val_res_f2{1});

% Genetic Algorithm 15 iteration measures for Function 2, D=10
max_D10_f2 = max(val_res_f2{2});
min_D10_f2 = min(val_res_f2{2});
mean_D10_f2 = mean(val_res_f2{2});
std_D10_f2 = std(val_res_f2{2});


disp('GA Results for 6:')
disp('D=2:');
disp(['Max Value: ', num2str(max_D2_f2)]);
disp(['Min Value: ', num2str(min_D2_f2)]);
disp(['Mean Value: ', num2str(mean_D2_f2)]);
disp(['Standard Deviation: ', num2str(std_D2_f2)]);
disp(' ');
disp('D=10:');
disp(['Max Value: ', num2str(max_D10_f2)]);
disp(['Min Value: ', num2str(min_D10_f2)]);
disp(['Mean Value: ', num2str(mean_D10_f2)]);
disp(['Standard Deviation: ', num2str(std_D10_f2)]);
